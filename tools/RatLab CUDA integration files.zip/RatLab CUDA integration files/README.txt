1. Make sure CUDA is installed and working.
2. It is recommended to use a local copy of MDP and not modify your system-wide installation.
2. Build shared library object from C source:

	$ gcc-4.5 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 module.c -o cudamult -lcuda -lcudart -lcublas
	$ gcc-4.5 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 -fPIC -c module.c -o libmodule.o -lcublas -lcuda -lcudart
	$ gcc-4.5 -shared -Wl,-soname,libcudamult.so -L/usr/local/cuda/lib64 -o libmodule.so libmodule.o -lcublas -lcuda -lcudart 

3. Copy shared library into your local MDP folder at (..)/mdp-toolkit/mdp/utils

4. Copy the covariance.py file from the MDP files folder to (..)/mdp-toolkit/mdp/utils
   You may also copy layer.py to (..)/mdp-toolkit/mdp/hinet
   (layer.py adds a progress bar so you can gauge the progress of the computations)

5. When using a local copy of MDP, make sure your scripts use it by setting the Python path variable:

	export PYTHONPATH=/(..)/mdp-toolkit
	