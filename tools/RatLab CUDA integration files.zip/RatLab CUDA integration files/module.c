//==============================================================================
//
//  Copyright (C) 2016 Fabian Schönfeld
//
//  This file is part of the ratlab software. It is free software; you can
//  redistribute it and/or modify it under the terms of the GNU General Public
//  License as published by the Free Software Foundation; either version 3, or
//  (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
//  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
//  more details.
//
//  You should have received a copy of the GNU General Public License along with
//  a special exception for linking and compiling against the pe library, the
//  so-called "runtime exception"; see the file COPYING. If not, see:
//  http://www.gnu.org/licenses/
//
//==============================================================================

// C/Python link test program

/* ----------------- CUDA 5
build:
	$ gcc-4.5 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 module.c -o cudamult -lcuda -lcudart -lcublas

build shared library object:
	$ gcc-4.5 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 -fPIC -c module.c -o libmodule.o -lcublas -lcuda -lcudart
	$ gcc-4.5 -shared -Wl,-soname,libcudamult.so -L/usr/local/cuda/lib64 -o libmodule.so libmodule.o -lcublas -lcuda -lcudart 

Note: linkage statements are parsed left-to-right; so objects 
containing external dependencies first, libraries satisfying 
those dependencies afterwards. (No idea why it worked the way
it is written below in the old version..)
*/

/*
build executable:
	$ gcc-4.4 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 -lcublas module.c -o module

build shared library object:
	$ gcc-4.4 -I/usr/local/cuda/include -L/usr/local/cuda/lib64 -lcublas -lcuda -lcudart -fPIC -c module.c -o libmodule.o
	$ gcc-4.4 -shared -Wl,-soname,libmodule.so -L/usr/local/cuda/lib64 -lcublas -lcuda -lcudart -o libmodule.so libmodule.o

check contents:
	$ nm libmodule.so

use built .so object in python:
	$ python
	>>> import ctypes
	>>> libmod = ctypes.cdll.LoadLibrary('libmodule.so')
	>>> libmod.check()
	create: 0
	destroy: 0
*/


#include "module.h"

int main(int argc, char** argv){

	int check = 0;
	unsigned int steps    = 5000;
	unsigned int channels = 100;
	unsigned int blocks   = 1;
	
	if( argc != 4 )
		printf("Using default example: 5000 steps, 100 channels, single block\n");
	else{
		unsigned int steps    = atoi(argv[1]);
		unsigned int channels = atoi(argv[2]);
		unsigned int blocks   = atoi(argv[3]);
		printf("Using custom example: %d steps, %d channels, %d block(s)\n", steps, channels, blocks);
	}

	printf("%d x %d data split into %d blocks\n", steps, channels, blocks);

	// setup random data
	unsigned int data_size = steps*channels*sizeof(float), i;
	float* data = (float*)malloc(data_size);
	float* res  = (float*)malloc(data_size);
	srand(2011);
	for(i=0; i<(steps*channels); i++){
		data[i] = rand()/(float)256.0;
		res[i]  = 0.0;
	}
	printf("random data initialized\n");

	printf("go cublas\n");
	check = cublas2ndMoment( data, steps, channels, res, blocks );
	printf("cublas done(%d)\n", check);
	
	printf("all done\n");
	return 0;
}

int cublas2ndMoment( const float* data, const unsigned int data_steps, const unsigned int data_channels, float* result, const unsigned int blocks ){

	// accumulated error codes
	int acc_err = 0;

	// data chunks
	unsigned int block_cols = data_steps/blocks;
	unsigned int block_size = data_channels*block_cols*sizeof(float);

	/* // optional memory alignment
	if( (block_size & (DEV_MEM_ALIGN-1)) != 0 ) // if( block_size%DEV_MEM_ALIGN != 0 )
		block_size = ((unsigned int)((((float)block_size)/((float)DEV_MEM_ALIGN))+0.5))*DEV_MEM_ALIGN;
	Note: makes no difference for 100.000x3320 matrices
	*/

	//fprintf( stderr, "\tsplitting data into %d blocks of size %d x %d (%d MB)\n",
	//	blocks, data_channels, block_cols, block_size/(1024*1024) );

	// device memory
	float* block_mem_dev = NULL;
	float* res_mem_dev   = NULL;
	cudaError_t cuda_error;

	cuda_error = cudaMalloc( (void**)&block_mem_dev, block_size );
	//fprintf( stderr, "\tblock malloc: %d\n", cuda_error );
	acc_err += cuda_error;

	unsigned int res_size = data_channels*data_channels*sizeof(float);
	cuda_error = cudaMalloc( (void**)&res_mem_dev, res_size );
	//fprintf( stderr, "\tresult malloc: %d\n", cuda_error );
	acc_err += cuda_error;

	// initialize cublas
	cublasHandle_t cublas_handle;
	cublasStatus_t cublas_status = cublasCreate( &cublas_handle );
	//fprintf( stderr, "\tcublas create: %d\n", cublas_status );
	acc_err += cublas_status;

	// compute 2nd moment matrix, iterate data blocks
	unsigned int i=0;
	for(i=0; i<blocks; i++){
		cuda_error = cudaMemcpy( block_mem_dev, &data[i*data_channels*block_cols], block_size, cudaMemcpyHostToDevice );
		float alpha = 1.0f;
		float beta  = (i==0) ? 0.0f : 1.0f;				// Sgemm: C = alpha*op(A)*op(B) + beta*C
		cublas_status = cublasSgemm( cublas_handle,		// handle to CUBLAS context
									 CUBLAS_OP_N,		// operation applied to matrix A in op(A)
									 CUBLAS_OP_T,		// operation applied to matrix B in op(B)
									 data_channels,		// rows of matrix op(A)
									 data_channels,		// columns of matrix op(B)
									 block_cols,		// columns of matrix A / rows of matrix B
									 &alpha,			// scalar parameter alpha
									 block_mem_dev,		// matrix A
									 data_channels,		// leading dimension of A
									 block_mem_dev,		// matrix B
									 data_channels,		// leading dimension of B
									 &beta,				// scalar parameter beta
									 res_mem_dev,		// matrix C
									 data_channels );	// leading dimension of C
		//fprintf( stderr, "\tsgemm[%d/%d]: %d\n", i+1, blocks, cublas_status );
		acc_err += cublas_status;
		cuda_error = cudaDeviceSynchronize();
		//fprintf( stderr, "\tsynch: %d\n", cuda_error );
		acc_err += cuda_error;
	}

	// fetch result & clean up
	cuda_error = cudaMemcpy( result, res_mem_dev, res_size, cudaMemcpyDeviceToHost );
	//fprintf( stderr, "\tfetch result: %d\n", cuda_error );
	acc_err += cuda_error;

	cuda_error = cudaFree( block_mem_dev );
	//fprintf( stderr, "\tfree block mem: %d\n", cuda_error );
	acc_err += cuda_error;

	cuda_error = cudaFree( res_mem_dev );
	//fprintf( stderr, "\tfree result mem: %d\n", cuda_error );
	acc_err += cuda_error;

	cublas_status = cublasDestroy( cublas_handle );
	//fprintf( stderr, "\tcublas destroy: %d\n", cublas_status );
	acc_err += cublas_status;

	// return
	return acc_err;
}

int cublas2ndMoment_F( const float* data, const unsigned int data_steps, const unsigned int data_channels, float* result, const unsigned int blocks ){

	/*
	In case a numpy array got re-ordered, use this function. '_F' denotes 
	Fortran notation, i.e., 'data' is the transposed data matrix, aka the data
	matrix in Fortran format. As such, its leading dimension is not data_steps
	instead of data_channels, and transposed when computing the 2nd moment 
	matrix. All changes from the original function are marked with '<---' tags.

	2nd moment of any matrix: m.T * m

	Original input: data matrix (with leading dimension data_channels), aka 
	transposed matrix in Fortran format, and thus:
	2nd moment = m.T * m = x * x.T		lda(x) = data_channels

	_F input: transposed data matrix (with leading dimension data_steps), aka
	original matrix in Fortran format -> has to be transposed first! 
	2nd	moment = m.T * m = x.T * x		lda(x) = data_steps
	*/

	// accumulated error codes
	int acc_err = 0;

	// data chunks
	unsigned int block_cols = data_steps/blocks;
	unsigned int block_size = data_channels*block_cols*sizeof(float);

	/* // optional memory alignment
	if( (block_size & (DEV_MEM_ALIGN-1)) != 0 ) // if( block_size%DEV_MEM_ALIGN != 0 )
		block_size = ((unsigned int)((((float)block_size)/((float)DEV_MEM_ALIGN))+0.5))*DEV_MEM_ALIGN;
	Note: makes no difference for 100.000x3320 matrices
	*/

	//fprintf( stderr, "\tsplitting data into %d blocks of size %d x %d (%d MB)\n",
	//	blocks, data_channels, block_cols, block_size/(1024*1024) );

	// device memory
	float* block_mem_dev = NULL;
	float* res_mem_dev   = NULL;
	cudaError_t cuda_error;

	cuda_error = cudaMalloc( (void**)&block_mem_dev, block_size );
	//fprintf( stderr, "\tblock malloc: %d\n", cuda_error );
	acc_err += cuda_error;

	unsigned int res_size = data_channels*data_channels*sizeof(float);
	cuda_error = cudaMalloc( (void**)&res_mem_dev, res_size );
	//fprintf( stderr, "\tresult malloc: %d\n", cuda_error );
	acc_err += cuda_error;

	// initialize cublas
	cublasHandle_t cublas_handle;
	cublasStatus_t cublas_status = cublasCreate( &cublas_handle );
	//fprintf( stderr, "\tcublas create: %d\n", cublas_status );
	acc_err += cublas_status;

	// compute 2nd moment matrix, iterate data blocks
	unsigned int i=0;
	for(i=0; i<blocks; i++){
		cuda_error = cudaMemcpy( block_mem_dev, &data[i*data_channels*block_cols], block_size, cudaMemcpyHostToDevice );
		float alpha = 1.0f;
		float beta  = (i==0) ? 0.0f : 1.0f;				// Sgemm: C = alpha*op(A)*op(B) + beta*C
		cublas_status = cublasSgemm( cublas_handle,		// handle to CUBLAS context
									 CUBLAS_OP_T,		// operation applied to matrix A in op(A)	<---
									 CUBLAS_OP_N,		// operation applied to matrix B in op(B)	<---
									 data_channels,		// rows of matrix op(A)
									 data_channels,		// columns of matrix op(B)
									 block_cols,		// columns of matrix A / rows of matrix B
									 &alpha,			// scalar parameter alpha
									 block_mem_dev,		// matrix A
									 data_steps,		// leading dimension of A					<---
									 block_mem_dev,		// matrix B
									 data_steps,		// leading dimension of B					<---
									 &beta,				// scalar parameter beta
									 res_mem_dev,		// matrix C
									 data_channels );	// leading dimension of C
		//fprintf( stderr, "\tsgemm[%d/%d]: %d\n", i+1, blocks, cublas_status );
		acc_err += cublas_status;
		cuda_error = cudaDeviceSynchronize();
		//fprintf( stderr, "\tsynch: %d\n", cuda_error );
		acc_err += cuda_error;
	}

	// fetch result & clean up
	cuda_error = cudaMemcpy( result, res_mem_dev, res_size, cudaMemcpyDeviceToHost );
	//fprintf( stderr, "\tfetch result: %d\n", cuda_error );
	acc_err += cuda_error;

	cuda_error = cudaFree( block_mem_dev );
	//fprintf( stderr, "\tfree block mem: %d\n", cuda_error );
	acc_err += cuda_error;

	cuda_error = cudaFree( res_mem_dev );
	//fprintf( stderr, "\tfree result mem: %d\n", cuda_error );
	acc_err += cuda_error;

	cublas_status = cublasDestroy( cublas_handle );
	//fprintf( stderr, "\tcublas destroy: %d\n", cublas_status );
	acc_err += cublas_status;

	// return
	return acc_err;
}

int check(){

	// setup
	float* data = NULL;
	unsigned int data_size = 0;
	unsigned int data_steps    = 0;
	unsigned int data_channels = 0;
	unsigned int data_blocks   = 4;
	
	// handcrafted example
	data_steps	  = 8;
	data_channels = 4;
	data_size = data_steps*data_channels*sizeof(float);
	data      = (float*)malloc(data_size);

	data[0] = 1;	data[4] = 2;    data[ 8] = 3;    data[12] = 4;    data[16] = 5;	   data[20] = 6;    data[24] = 7;    data[28] = 8;
	data[1] = 9;	data[5] = 10;   data[ 9] = 11;   data[13] = 12;   data[17] = 13;   data[21] = 14;   data[25] = 15;   data[29] = 16;
	data[2] = 17;   data[6] = 18;   data[10] = 19;   data[14] = 20;   data[18] = 21;   data[22] = 22;   data[26] = 23;   data[30] = 24;
	data[3] = 25;   data[7] = 26;   data[11] = 27;   data[15] = 28;   data[19] = 29;   data[23] = 30;   data[27] = 31;   data[31] = 32;	

	/* example above conains signals of successive numbers in C/Python row major order
	1  9 17 25					 0  1  2  3
	2 10 18 26 					 4  5  6  7
	3 11 19 27 					 8  9 10 11
	4 12 20 28 	 with indices:  12 13 14 15
	5 13 21 29  				16 17 18 19
	6 14 22 30 					20 21 22 23
	7 15 23 31 					24 25 26 27
	8 16 24 32 					28 29 30 31
	*/

	// run 2nd moment
	float* result = (float*)malloc( data_channels*data_channels*sizeof(float) );
	cublas2ndMoment( data, data_steps, data_channels, result, data_blocks );

	unsigned int i,j;
	for(i=0; i<data_channels; i++){
		for(j=0; j<data_channels; j++)
			printf("%.1f\t", result[j*data_channels+i]); // <----- note: i*colB+j would be used normally, ie, this is printing the transpose
		printf("\n");								   // why: we're getting the transpose vial col/row primary difference
	}

	
	/* SIMPLE CUBLAS TEST

	// init cublas
	cublasHandle_t cublas_handle;
	cublasStatus_t cublas_status = cublasCreate( &cublas_handle );
	printf( "create: %d\n", cublas_status );

	// example
	float* data = NULL;
	float* res  = NULL;
	res  = (float*)malloc(sizeof(float)*4);
	data = (float*)malloc(sizeof(float)*4);
	data[0] = 1.0;		data[2] = 2.0;
	data[1] = 2.0;		data[3] = 3.0;

	// device memory
	float* data_dev = NULL;
	float* res_dev  = NULL;
	cublas_status = cudaMalloc( (void**)&data_dev, sizeof(float)*4 );
	printf( "alloc #1: %d\n", cublas_status );
	cublas_status = cudaMalloc( (void**)&res_dev,  sizeof(float)*4 );
	printf( "alloc #2: %d\n", cublas_status );

	// set matrix
	cublas_status = cublasSetMatrix( 2,2,sizeof(float),(void*)data,2,(void*)data_dev,2 );
	printf( "set: %d\n", cublas_status );
	
	// blas sgemm: C = alpha * op(A)*op(B) + beta*C
	float alpha = 1.0;
	float beta  = 0.0;
	cublas_status = cublasSgemm( cublas_handle,		// handle to cublas context
								 CUBLAS_OP_N,		// op(A) identifier
								 CUBLAS_OP_N,		// op(B) identifier
								 2,					// rows of matrix op(A) & C
								 2,					// columns of matrix op(B) & C
								 2,					// columns of op(A) & rows of op(C)
								 &alpha,			// scalar alpha
								 data_dev, 2,		// matrix A with leading dimension
								 data_dev, 2,		// matrix B with leading dimension
								 &beta,				// scalar beta
								 res_dev, 2 );		// matrix C with leading dimension
	printf( "sgemm: %d\n", cublas_status );
	
	// get matrix
	cublas_status = cublasGetMatrix( 2,2,sizeof(float),(void*)res_dev,2,(void*)res,2 );
	printf( "get: %d\n", cublas_status );
	printf("[%.1f\t%.1f]\n[%.1f\t%.1f]\n", res[0], res[1], res[2], res[3] );

	// clean up
	cublas_status = cublasDestroy( cublas_handle );
	printf( "destroy: %d\n", cublas_status );
	return 0;
	*/


	/*	LEGACY CUBLAS

	// cublas init
	cublasStatus_t cublas_status = cublasInit();
	printf("init: %d\n", cublas_status);
	
	// example
	float* data = NULL;
	float* res  = NULL;
	res  = (float*)malloc(sizeof(float)*4);
	data = (float*)malloc(sizeof(float)*4);
	data[0] = 1.0;		data[2] = 2.0;
	data[1] = 2.0;		data[3] = 3.0;

	// device memory
	float* data_dev = NULL;
	float* res_dev  = NULL;
	cublas_status = cublasAlloc( 4, sizeof(float), (void**)&data_dev );
	printf("alloc data: %d\n", cublas_status);
	cublas_status = cublasAlloc( 4, sizeof(float), (void**)&res_dev  );
	printf("alloc res:  %d\n", cublas_status);
	
	// set matrix
	cublas_status = cublasSetMatrix(2,2,sizeof(float),data,2,data_dev,2);
	printf("set data: %d\n", cublas_status);

	// multiply
	cublasSgemm('N','N',2,2,2,1.0,data_dev,2,data_dev,2,0.0,res_dev,2);
	printf("gemm: %d\n", cublas_status);

	// get matrix
	cublas_status = cublasGetMatrix(2,2,sizeof(float),res_dev,2,res,2);
	printf("get: %d\n", cublas_status);
	printf("[%.1f\t%.1f]\n[%.1f\t%.1f]\n", res[0], res[1], res[2], res[3] );
	
	// clean up
	cublas_status = cublasShutdown();
	printf("shutdown: %d\n", cublas_status);
	printf("all done\n");
	*/
}

