//==============================================================================
//
//  Copyright (C) 2016 Fabian Schönfeld
//
//  This file is part of the ratlab software. It is free software; you can
//  redistribute it and/or modify it under the terms of the GNU General Public
//  License as published by the Free Software Foundation; either version 3, or
//  (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
//  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
//  more details.
//
//  You should have received a copy of the GNU General Public License along with
//  a special exception for linking and compiling against the pe library, the
//  so-called "runtime exception"; see the file COPYING. If not, see:
//  http://www.gnu.org/licenses/
//
//==============================================================================


#include "stdlib.h"
#include "stdio.h"

#include "cublas_v2.h"

#define DEV_MEM_ALIGN 32


int main(int, char**);
int check();
int cublas2ndMoment( const float* data, const unsigned int data_steps, const unsigned int data_channels, float* result, const unsigned int blocks );
